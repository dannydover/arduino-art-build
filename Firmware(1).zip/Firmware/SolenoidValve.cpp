#include "SolenoidValve.h"

/* This file is empty because the functionalty of SolenoidValve 
 * is implemented in Switchable
 */
 